#!/usr/bin/env bash
set -x
set -e

cd third_party/oio-sds
cmake \
	-DCMAKE_INSTALL_PREFIX=$BASE \
	-DLD_LIBDIR=lib \
	-DAPACHE2_INCDIR=/usr/include/apache2 \
	-DAPACHE2_LIBDIR=/usr/lib/apache2 \
	-DAPACHE2_MODDIR=${LIB}/apache2/module \
	-DASN1C_LIBDIR=${LIB} .
make $MAKE_PARALLEL
make install
python ./setup.py develop
cd -
