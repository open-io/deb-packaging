#!/usr/bin/env bash
set -x
set -e

cd third_party/asn1c
autoreconf -f -i
./configure \
	--prefix=$BASE \
	--enable-{static,shared}
make $MAKE_PARALLEL
make install
cd -
