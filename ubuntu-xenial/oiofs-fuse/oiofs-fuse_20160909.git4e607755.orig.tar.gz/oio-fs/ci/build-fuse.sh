#!/usr/bin/env bash
set -x
set -e

cd third_party/libfuse
./makeconf.sh
./configure \
	--prefix=$BASE \
	--libdir=$BASE/lib \
	--enable-static \
	--enable-test
make $MAKE_PARALLEL
cd -

