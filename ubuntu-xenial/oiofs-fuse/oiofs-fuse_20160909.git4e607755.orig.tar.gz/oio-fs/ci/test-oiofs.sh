#!/usr/bin/env bash
set -x
set -e

export COLUMNS=500

function dump_syslog {
	set +e
	ps -efjH
	ulimit -a
	python --version
	gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock status2
	echo "Keys *" | redis-cli
	echo get OPENIO/OIOFS/vol01:inode_bitmap | redis-cli
	sudo tail -n 500 /var/log/syslog
}

trap dump_syslog EXIT

## Call the unit tests first
#make test

## Special env for the CI, where ZOOKEEPER and REDIS are already managed
oio-reset.sh -f ci/bootstrap-SINGLE.yml

## let's add the oiofs-server
cat >> $HOME/.oio/sds/conf/gridinit.conf <<EOF
[service.${OIO_NS}-oiofs]
group=${OIO_NS},localhost,oiofs,127.0.0.1:4341
on_die=respawn
enabled=true
start_at_boot=true
command=oiofs_server --register-interval 5 --redis-host 127.0.0.1 --redis-port 6379 ${OIO_NS}
EOF

gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock reload
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock start
oio-wait-scored.sh -u -n $OIO_NS

#install redis-server
sudo add-apt-repository ppa:chris-lea/redis-server -y
sudo apt-get update
sudo apt-get install redis-server

#make directory 
sudo mkdir -p -m 777 /mnt/
sudo mkdir -p -m 777 /mnt/oiofs
sudo mkdir -p -m 777 /tmp/oiofs-cache 

mkdir -p -m 777 ${HOME}/$OIO_ACCOUNT/
mkdir -p -m 777 ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER

echo "/mnt/oiofs 127.0.0.1(rw,sync,no_root_squash,no_all_squash,no_subtree_check,fsid=0)" | sudo tee -a /etc/exports
sudo /usr/sbin/exportfs -a

echo $(/usr/bin/id -nu)

#test directory
ls ${HOME}/$OIO_ACCOUNT/ -liR
ls /mnt/ -liR

#start redis and test
sudo sysctl vm.overcommit_memory=1
sudo service redis-server start

#sudo sed -i.bak 's/^\(tcp-keepalive \).*/\160/' /etc/redis/redis.conf
#sudo service redis-server restart
#sleep 5

mkfs.oiofs $OIO_NS/$OIO_ACCOUNT/$OIO_CONTAINER -m 0755 -u $(/usr/bin/id -nu)

oiofs_fuse -s -v \
	--oiofs-server 127.0.0.1:4341 \
	--oiofs-cache-dir /tmp/oiofs-cache \
	-o default_permissions \
	-o allow_other \
	--oiofs-user-url $OIO_NS/$OIO_ACCOUNT/$OIO_CONTAINER \
	/mnt/oiofs

ps aux | grep fuse

sudo /bin/mount -o v3 -v -t nfs -o nordirplus 127.0.0.1:/mnt/oiofs ${HOME}/oiofs/$OIO_CONTAINER

./third_party/libfuse/test/test ${HOME}/oiofs/$OIO_CONTAINER

sudo umount ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/  
fusermount -u ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/
sudo service nfs-kernel-server restart

ps aux | grep fuse


