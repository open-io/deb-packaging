#!/bin/bash
#
# Start OpenIO

export BASE_DIR=All-builds
export MAKE_PARALLEL="-j 8"
export BASE=/home/SDS/install
export prefix=$BASE
export INC=$BASE/include
export LIB=$BASE/lib
export PATH=${PATH}:${BASE}/bin

#not used should be remove
export PKG_CONFIG_PATH=${BASE}/lib/pkgconfig
export VIRTENV=/home/SDS/virtualenvs
export DATA=/home/SDS/data
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${LIB}
export CFLAGS="-I$BASE/include"
export CXXFLAGS="-I$BASE/include"
export LDFLAGS="-L$BASE/lib"
export LDXXFLAGS="-L$BASE/lib"

export OIO_NS=OPENIO
export OIO_ACCOUNT=oiofs
export OIO_CONTAINER=oiofs1

case "$1" in

kill)
deactivate
;;

setup)
virtualenv oio --system-site-packages
source "./oio/bin/activate"
cd $BASE_DIR/oio-sds
pip install --upgrade -r all-requirements.txt
python ./setup.py develop
cd ..
cd ..
;;

start )
echo "setup gridinit"
gridinit -s RC,gridinit -d $HOME/.oio/sds/conf/gridinit.conf
echo "starting openio services"
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock start 
echo "status openio services"
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock status
echo "oio-cluster..."
;;

oio)
sleep 5
oio-cluster -r OPENIO | awk -F\| '/score=0/{print $1"|"$2"|"$3}' | while read S ; do ( set -x ; oio-cluster --set-score=1 -S "$S" ) ; done
oio-cluster  OPENIO -r | xargs -n1 oio-cluster OPENIO --unlock-score -S
;;

    reset)
./$BASE_DIR/oio-sds/tools/oio-reset.sh -f bootstrap-SINGLE.yml -v

echo "add add the oiofs-server"
## let's add the oiofs-server
cat >> $HOME/.oio/sds/conf/gridinit.conf <<EOF
[service.${OIO_NS}-oiofs]
group=${OIO_NS},localhost,oiofs,127.0.0.1:4341
on_die=respawn
enabled=true
start_at_boot=true
command=oiofs_server --register-interval 5 --redis-host 127.0.0.1 --redis-port 6379 ${OIO_NS}
EOF
echo "done"

echo "restart oio-dsd and unlock score"
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock reload
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock start
sleep 2
oio-wait-scored.sh -u -n $OIO_NS
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock status
;; 

    stop)
echo "stoping openio services"
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock stop 
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock status
;;

    status)
gridinit_cmd -S $HOME/.oio/sds/run/gridinit.sock status
;;
	
    list)
openio object list $2 --oio-ns OPENIO --oio-account $OIO_ACCOUNT
;;

    delete) 
openio container delete $2 --oio-ns OPENIO --oio-account $OIO_ACCOUNT
;;

    create)
openio container create $2 --oio-ns OPENIO --oio-account $OIO_ACCOUNT
;;

    deleteo)
openio object delete $2 $3 --oio-ns OPENIO --oio-account $OIO_ACCOUNT
;;

    createo)
openio object create $2 $3 --oio-ns OPENIO --oio-account $OIO_ACCOUNT $4
;;

    *)
        echo "Usage: $0 {start|stop|list [container] | delete [container] | create [container] }"
        ;;
esac
