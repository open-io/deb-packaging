#!/usr/bin/env bash
set -x
set -e

export BASE_DIR=All-builds

cd $BASE_DIR
if [ ! -d "libfuse" ]; then
git clone https://github.com/libfuse/libfuse
fi
cd libfuse
./makeconf.sh
./configure \
	--libdir=/usr/lib 
make 
cd -


