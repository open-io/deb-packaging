#!/bin/bash
#

export OIO_NS=OPENIO
export OIO_ACCOUNT=OIOFS

case "$1" in

all)
echo "Keys *" | redis-cli
;;

dir)
echo "keys $OIO_NS/$OIO_ACCOUNT/$2:dirent*" | redis-cli
;;

index)
echo "hgetall $OIO_NS/$OIO_ACCOUNT/$2:dirent:$3:index" | redis-cli
;;

file)
echo "hgetall $OIO_NS/$OIO_ACCOUNT/$2:inode:$3" | redis-cli
;;


clear)
sudo service redis-server stop
sudo rm /var/lib/redis/dump.rdb
sudo service redis-server start
 
;;

*)
echo "Usage: $0 { all | dir container_name | file container_name  #inode | index container_name #inode }"
;;
esac

