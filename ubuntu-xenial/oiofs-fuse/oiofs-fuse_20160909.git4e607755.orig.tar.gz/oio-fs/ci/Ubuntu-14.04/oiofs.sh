#!/bin/bash
#
# 

### FUSE
# apt-get install oiofs-fuse fuse redis-server
# /usr/bin/oiofs_server --bind 127.0.0.1:4341 --register-interval 5 --redis-host 127.0.0.1 --redis-port 6379 OPENIO
# oio-cluster  OPENIO -r | xargs -n1 oio-cluster OPENIO --unlock-score -S
# mkfs.oiofs OPENIO/myaccount/mycontainer1
# mkdir /mnt/mountpoint1
# /usr/bin/oiofs_fuse --oiofs-server 127.0.0.1:4341 --oiofs-timeout 5 --oiofs-cache-dir /tmp/oiofs-cache -s -o default_permissions -o allow_other --oiofs-user-url OPENIO/myaccount/mycontainer1 /mnt/mountpoint1
# fusermount -u /mnt/mountpoint1


#    sudo ldconfig /user/local/lib/  # to register liboiofs.so


set -e
OIOFS_IP=127.0.0.1   #  is the IP address of your NFS server
OIOFS_PORT=4341      #  is the port that the oiofs-server will listen
REDIS_IP=127.0.0.1  # is the IP address of your redis server
REDIS_PORT=6379          # is the port of your redis server
OIO_NS=OPENIO		 # is the name of your namespace
OIO_ACCOUNT=oiofs	 # is the name of your account(s) in the namespace (you can create several, e.g. one by user group)
OIO_CONTAINER=oiofs1	 # is the name of the container that will host your filesystem (you can create several per account, e.g. one per end user)
#export LD_LIBRARY_PATH=/usr/lib64:/usr/local/lib/

case "$1" in

setup)
	echo "make all dir for oio-fs test"
	sudo mkdir -p -m 777 /mnt/
	sudo mkdir -p -m 777 /mnt/$OIO_ACCOUNT/
	sudo mkdir -p -m 777 /mnt/$OIO_ACCOUNT/$OIO_CONTAINER

	mkdir -p -m 777 ${HOME}/$OIO_ACCOUNT/
	mkdir -p -m 777 ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
        mkdir -p -m 777 ${HOME}/oiofs-cache

	if grep /mnt/$OIO_ACCOUNT/$OIO_CONTAINER /etc/exports > /dev/null
	then
	   sleep 0.1
	else
	echo "/mnt/$OIO_ACCOUNT/$OIO_CONTAINER 127.0.0.1(rw,sync,no_root_squash,no_all_squash,no_subtree_check,fsid=0)" | sudo tee -a /etc/exports
	sudo /usr/sbin/exportfs -a
        echo "user_allow_other" | sudo tee -a /etc/fuse.conf
	fi
	
;;

	start)

oiofs_server --bind $OIOFS_IP:$OIOFS_PORT --register-interval 5 --redis-host $REDIS_IP --redis-port $REDIS_PORT $OIO_NS 
;;

	bind)
mkfs.oiofs $OIO_NS/$OIO_ACCOUNT/$OIO_CONTAINER -m 0755 -u $(/usr/bin/id -nu)
;;

	fuse)
        oiofs_fuse --oiofs-server 127.0.0.1:4341 --oiofs-cache-dir ${HOME}/oiofs-cache -s -o default_permissions -o allow_other --oiofs-user-url $OIO_NS/$OIO_ACCOUNT/$OIO_CONTAINER /mnt/oiofs/$OIO_CONTAINER
;;
        umount1) 
        sudo umount ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER  || true
        fusermount -uz /mnt/$OIO_ACCOUNT/$OIO_CONTAINER || true
        sudo service nfs-kernel-server restart || true
;;

        umount) 
        sudo umount ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER 
;;

	export)
         sudo service nfs-kernel-server restart
;;

	clear)
        fusermount -uz /mnt/oiofs/$OIO_CONTAINER
	sudo umount /home/raymond/oiofs/$OIO_CONTAINER
;;

	mountf)
        sshfs 127.0.0.1:/mnt/oiofs/$OIO_CONTAINER ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
;;

	mount)
#	mkdir -p /home/raymond/oiofs/$OIO_CONTAINER
##	sudo chmod -R 777 /home/raymond/oiofs

	sudo /bin/mount -o v3 -v -t nfs -o nordirplus 127.0.0.1:/mnt/oiofs/$OIO_CONTAINER ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
#	mkdir -p ~/$OIO_CONTAINER
#	sudo mount -o v3 -t nfs -o nordirplus 127.0.0.1:/mnt/oiofs/$OIO_CONTAINER ~/$OIO_CONTAINER
;;

        fumount)
        fusermount -u ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac



