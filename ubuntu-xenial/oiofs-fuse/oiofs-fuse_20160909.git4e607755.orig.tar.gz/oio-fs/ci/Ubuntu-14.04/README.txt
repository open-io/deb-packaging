Create a fresh Ubuntu installation 14.04
Copy all scripts info a sub directory from ${HOME}
make a sub directory: All-builds

from a GNOME Terminal
1) ./build-all.sh
2) reboot

from a GNOME Terminal to get oio-sds up and running
3) . openio.sh setup        ==> set up python virtual environment

4) . openio.sh reset        ==> oio-reset 
	or
5) . openio.sh start        ==> start all services
6) . openio.sh oio          ==> unlock scores

7) . openio.sh stop         ==> stop all services
8) . openio.sh kill         ==> exit virtual environment


from a GNOME Terminal 
9)  ./oiofs.sh setup           ==> create all directory needed to mount and other stuff
10) ./oiofs.sh bind            ==> mkfs_oiofs 
 
11) ./oiofs.sh fuse	    ==> to start oiofs_fuse
12) ./oiofs.sh mount	    ==> NFS mount
or
13) ./oiofs.sh mountf	    ==> sshfs mount	 
14) ./oiofs.sh umount1	    ==>> un-mount and stop oiofs_fuse	


Full fuse test require 1,2,3,4,9 and 10
15  ./fuse-test.sh large_file  

the test will:
a) mount NFS
b) copy large file
c) binary compare of large file
d) copy oio_sds directory
e) ls -liR on oio_sds
f) un-mount
g) mount sshfs
h) binary compare of large file
i) rm oio_sds
j) rm on large file
k) un-mount



