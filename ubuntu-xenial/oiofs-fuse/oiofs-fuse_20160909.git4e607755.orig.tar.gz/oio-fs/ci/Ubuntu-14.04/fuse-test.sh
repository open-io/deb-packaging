#!/usr/bin/env bash

export OIO_NS=OPENIO
export OIO_ACCOUNT=oiofs
export OIO_CONTAINER=oiofs1
export BASE_DIR=All-builds

./oiofs.sh setup
sleep 2

echo "./oiofs.sh fuse"
./oiofs.sh fuse
sleep 5
# NFS mount
echo "./oiofs.sh mount"
./oiofs.sh mount

echo "press enter"
read a

echo "libfuse test"
${HOME}/$BASE_DIR/libfuse/test/test ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
echo "press enter"
read a

echo "cp $1"
cp $1 ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/$1
sleep 5
echo "cmp  $1"
cmp -l $1 ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/$1 | gawk '{printf "%08X %02X %02X\n", $1, strtonum(0$2), strtonum(0$3)}'

echo "press enter"
read a

echo "cp oio-sds"
cp -R $BASE_DIR/oio-sds ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/oio-sds
ls ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/oio-sds -liR
echo "press enter"
read a

echo "list oio-sds objects"
./openio.sh list "$OIO_CONTAINER"_0 | sort -k2 -n 

echo "press enter"
read a

echo "umount"
./oiofs.sh umount1
sleep 5

echo "press enter"
read a

ps aux | grep fuse

echo "press enter"
read a

echo "./oiofs.sh fuse"
./oiofs.sh fuse
sleep 5

echo "press enter"
read a

# sshfs mount
echo "./oiofs.sh mountf"
./oiofs.sh mountf

sleep 5
echo "press enter"
read a

echo "cmp -l $1"
cmp -l $1 ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/$1 | gawk '{printf "%08X %02X %02X\n", $1, strtonum(0$2), strtonum(0$3)}'
sleep 5

echo "press enter"
read a

echo "list oio-sds objects"
./openio.sh list "$OIO_CONTAINER"_0 | sort -k2 -n 

echo "press enter"
read a

echo "rm oio-sds"
rm -R ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/oio-sds

echo "press enter"
read a

echo "list oio-sds objects"
./openio.sh list "$OIO_CONTAINER"_0 | sort -k2 -n 

echo "press enter"
read a

echo "rm $1"
rm ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER/$1
echo "press enter"
read a

echo "list oio-sds objects"
./openio.sh list "$OIO_CONTAINER"_0 | sort -k2 -n 
echo "press enter"
read a

echo "libfuse test"
${HOME}/$BASE_DIR/libfuse/test/test ${HOME}/$OIO_ACCOUNT/$OIO_CONTAINER
echo "press enter"
read a

./oiofs.sh umount1



