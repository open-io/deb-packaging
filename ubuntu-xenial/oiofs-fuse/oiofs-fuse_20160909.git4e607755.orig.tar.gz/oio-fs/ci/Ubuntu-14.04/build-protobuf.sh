#!/usr/bin/env bash
set -x
set -e
export BASE_DIR=All-builds

cd $BASE_DIR/grpc/third_party/protobuf
./autogen.sh
./configure
make
make check || true
sudo make install
sudo ldconfig
protoc --version
cd -

