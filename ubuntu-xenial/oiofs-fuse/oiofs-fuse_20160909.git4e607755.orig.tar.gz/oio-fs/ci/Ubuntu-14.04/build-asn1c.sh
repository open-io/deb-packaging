#!/usr/bin/env bash
set -x
set -e

cd $BASE_DIR
if [ ! -d "asn1c" ]; then
git clone https://github.com/open-io/asn1c.git
fi
cd asn1c
autoreconf -f -i
./configure 
make 
sudo make install
cd ../..
