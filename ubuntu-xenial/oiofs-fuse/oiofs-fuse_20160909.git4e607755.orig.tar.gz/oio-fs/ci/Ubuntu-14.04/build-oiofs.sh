#!/usr/bin/env bash
set -x
set -e
export BASE_DIR=All-builds
export PKG_CONFIG_PATH=/usr/local/lib64/pkgconfig

cd $BASE_DIR
if [ ! -d "oio-fs" ]; then
git clone https://github.com/jfsmig/oio-fs/
fi
cd ..
cp -avrn $BASE_DIR/grpc/third_party/googletest/ $BASE_DIR/oio-fs/third_party/
cd $BASE_DIR
cd oio-fs
sudo rm -r $(cat install_manifest.txt) || true
make clean || true
cmake  \
   -DGPR_LIBDIR=/usr/lib \
   -DLD_LIBDIR=/usr/lib \
 ../oio-fs/
make
sudo make install


