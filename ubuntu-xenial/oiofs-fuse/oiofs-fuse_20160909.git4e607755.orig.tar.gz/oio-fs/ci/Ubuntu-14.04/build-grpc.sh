#!/usr/bin/env bash
set -x
set -e

cd $BASE_DIR
if [ ! -d "grpc" ]; then
git clone https://github.com/grpc/grpc.git
cd grpc
git submodule update --init
make 
sudo make install
fi
cd -
