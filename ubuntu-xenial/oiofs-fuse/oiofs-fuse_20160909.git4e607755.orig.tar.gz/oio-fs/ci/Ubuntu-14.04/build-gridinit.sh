#!/usr/bin/env bash
set -x
set -e

cd $BASE_DIR
if [ ! -d "gridinit" ]; then
git clone https://github.com/open-io/gridinit.git
fi
cd gridinit
cmake \
	-DLD_LIBDIR=lib \
	-DGRIDINIT_SOCK_PATH=$HOME/.oio/sds/run/gridinit.sock .
make $MAKE_PARALLEL
sudo make install
cd -


