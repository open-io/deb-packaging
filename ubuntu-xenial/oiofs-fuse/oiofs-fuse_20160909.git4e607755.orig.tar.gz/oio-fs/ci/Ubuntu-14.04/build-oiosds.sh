#!/usr/bin/env bash
set -x
set -e

export BASE_DIR=All-builds

#      	-DCMAKE_INSTALL_PREFIX=/usr \
#        -DLD_LIBDIR=/lib \

cd $BASE_DIR
if [ ! -d "oio-sds" ]; then
git clone https://github.com/open-io/oio-sds
fi
cd oio-sds
sudo rm -r $(cat install_manifest.txt) || true
make clean || true
cmake \
	-DAPACHE2_INCDIR=/usr/include/apache2 \
	-DAPACHE2_LIBDIR=/usr/lib/apache2 \
	-DAPACHE2_MODDIR=/usr/sbin/ \
	-DASN1C_LIBDIR=/usr/lib
make 
sudo make install

echo "/usr/local/lib64" | sudo tee -a /etc/ld.so.conf.d/libc.conf
sudo ldconfig

cd -

