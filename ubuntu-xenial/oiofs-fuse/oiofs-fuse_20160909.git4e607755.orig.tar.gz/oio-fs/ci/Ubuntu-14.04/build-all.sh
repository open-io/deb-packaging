
#!/usr/bin/env bash
set -e
export BASE_DIR=All-builds
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig

echo "apt-get install pkg-config git gcc libtool autoconf automake cmake make bison flex"
sudo apt-get install -y pkg-config git gcc libtool autoconf automake cmake make bison flex
echo done

echo "apt-get install bison libevent-dev libpackagekit-glib2-dev libcurl3 libcurl3-dev php5-curl curl"
sudo apt-get install -y bison libevent-dev libpackagekit-glib2-dev libcurl3 libcurl3-dev php5-curl curl
echo done

echo "apt-get install libattr1-dev libattr1 attr"
sudo apt-get install -y libattr1-dev libattr1 attr
echo done

echo "apt-get install libjson-c-dev libjson-c2"
sudo apt-get install -y libjson-c-dev libjson-c2
echo done

echo "apt-get install libevent-dev libevent-2.0-5"
sudo apt-get install -y libevent-dev libevent-2.0-5
echo done

echo "apt-get install libzmq3-dev libzmq3"
sudo apt-get install -y libzmq3-dev libzmq3
echo done

echo "apt-get install libhiredis-dev libhiredis0.10"
sudo apt-get install -y libhiredis-dev libhiredis0.10 
echo done

echo "apt-get install apache2 apache2-dev libapache2-mod-wsgi"
sudo apt-get install -y apache2 apache2-dev libapache2-mod-wsgi
echo done

echo "apt-get install liblzo2-2 liblzo2-dev zlib1g zlib1g-dev"
sudo apt-get install -y liblzo2-2 liblzo2-dev zlib1g zlib1g-dev
echo done

echo "apt-get install libzookeeper-mt2 libzookeeper-mt-dev zookeeper zookeeper-bin"
sudo apt-get install -y libzookeeper-mt2 libzookeeper-mt-dev zookeeper zookeeper-bin
echo done

echo "apt-get install libfuse2 libfuse-dev fuse"
sudo apt-get install -y libfuse2 libfuse-dev fuse
echo done

echo "apt-get install libleveldb1 libleveldb-dev"
sudo apt-get install -y libleveldb1 libleveldb-dev
echo done

echo "apt-get install libgoogle-glog0 libgoogle-glog-dev"
sudo apt-get install -y libgoogle-glog0 libgoogle-glog-dev
echo done

echo "apt-get install liberasurecode1 liberasurecode-dev"
sudo apt-get install -y liberasurecode1 liberasurecode-dev
echo done

echo "apt-get install python-pip"
sudo apt-get install -y python-pip
echo done

echo "apt-get install python-virtualenv"
sudo apt-get install -y python-virtualenv
echo done

echo "apt-get install python-dev libpython-dev"
sudo apt-get install -y python-dev libpython-dev
echo done

echo "apt-get install nfs-kernel-server"
sudo apt-get install -y nfs-kernel-server gawk
echo done

echo "install redis-server"
sudo add-apt-repository ppa:chris-lea/redis-server -y
sudo apt-get update
sudo apt-get install redis-server -y
sudo sed -i.bak 's/^\(tcp-keepalive \).*/\160/' /etc/redis/redis.conf
sudo service redis-server restart
sudo addgroup $(/usr/bin/id -nu) fuse  
sudo usermod -aG fuse $(/usr/bin/id -nu)
#must reboot after this to take effect (this is for oiofs-fuse more precisely loading etc\fuse.conf)

echo "done"

echo "apt-get install sshfs"
sudo apt-get install -y sshfs
echo done

echo "apt-get install beanstalkd"
sudo apt-get install -y beanstalkd
echo done

echo "./build-asn1c.sh"
./build-asn1c.sh
echo done

echo "./build-gridinit.sh"
./build-gridinit.sh
echo done

echo "./build-oiosds.sh"
./build-oiosds.sh
echo done

echo "./build-grpc.sh"
./build-grpc.sh
echo done

echo "./build-protobuf.sh"
./build-protobuf.sh
echo done

echo "./build-oiofs.sh"
./build-oiofs.sh
echo done

echo "./build-fuse.sh"
./build-fuse.sh
echo done

echo done

