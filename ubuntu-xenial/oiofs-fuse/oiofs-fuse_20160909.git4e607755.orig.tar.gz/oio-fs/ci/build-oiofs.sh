#!/usr/bin/env bash
set -x
set -e

cmake \
	-DCMAKE_INSTALL_PREFIX=$BASE \
	-DLD_LIBDIR=lib \
	-DPROTOC_EXECUTABLE=$BASE/bin/protoc \
	.
make $MAKE_PARALLEL
make install
