#!/usr/bin/env bash
set -x
set -e

cd third_party/grpc/third_party/googletest
cmake -DCMAKE_INSTALL_PREFIX=$BASE .
make $MAKE_PARALLEL
install libgtest.a libgtest_main.a "$LIB/"
cp -rp include/gtest "$INC/"
cd -

