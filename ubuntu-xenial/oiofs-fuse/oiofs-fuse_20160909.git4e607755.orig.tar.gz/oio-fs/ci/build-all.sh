#!/usr/bin/env bash
set -e
./ci/build-asn1c.sh
./ci/build-gridinit.sh
./ci/build-oiosds.sh
./ci/build-gtest.sh
./ci/build-gflags.sh
./ci/build-protobuf.sh
./ci/build-grpc.sh
