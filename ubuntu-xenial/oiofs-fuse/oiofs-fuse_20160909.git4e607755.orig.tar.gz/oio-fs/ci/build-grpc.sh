#!/usr/bin/env bash
set -x
set -e

cd third_party/grpc
make $MAKE_PARALLEL
make install
cd -
