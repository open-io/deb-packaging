#!/usr/bin/env bash
set -x
set -e

cd third_party/gridinit
cmake \
	-DCMAKE_INSTALL_PREFIX=$BASE \
	-DLD_LIBDIR=lib \
	-DGRIDINIT_SOCK_PATH=$HOME/.oio/sds/run/gridinit.sock .
make $MAKE_PARALLEL
make install
cd -
