 print("hello")

local ping = redis.call ("ping")

print("ping = ", ping)

local fsid = KEYS[1]
local mode = KEYS[2]
local uid = KEYS[3]
local gid = KEYS[4]
local time = KEYS[5]

local clear_bitmap = redis.call('DEL', fsid..':inode_bitmap', unpack(redis.call('KEYS', fsid..':*')))
print ("clear bitmap = ", clear_bitmap)
local create_bitmap = redis.call('SETBIT', fsid..':inode_bitmap', 0, 1)
print ("create bitmap = ", create_bitmap)

local ino = redis.call('BITPOS', fsid..':inode_bitmap', 0)
print ("ino = ", ino)

local set_bit = redis.call('SETBIT', fsid..':inode_bitmap', ino, 1)
print ("set_bit = ", set_bit)

local hmset = redis.call('HMSET', fsid..':inode:'..ino, 'mode', mode, 'uid', uid, 'gid', gid, 'size', 0, 'atime', time, 'ctime', time, 'mtime', time, 'nlink', 0,'generation', time);
return hmset
