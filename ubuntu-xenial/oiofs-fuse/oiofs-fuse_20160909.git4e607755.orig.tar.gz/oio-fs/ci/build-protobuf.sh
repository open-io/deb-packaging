#!/usr/bin/env bash
set -x
set -e

cd third_party/grpc/third_party/protobuf
./autogen.sh
#autoreconf -f -i
./configure \
	--prefix=$BASE \
	--libdir=$BASE/lib \
	--enable-{static,shared}
make $MAKE_PARALLEL
make install
cd -

