#ifndef	_ASN1FIX_CLASS_H_
#define	_ASN1FIX_CLASS_H_

/*
 * Fetch the element from the class-related stuff (thing) by its reference.
 */
asn1p_expr_t *asn1f_class_access(arg_t *, asn1p_module_t *mod, asn1p_expr_t *rhs_pspecs, asn1p_ref_t *);

#endif	/* _ASN1FIX_CLASS_H_ */
