# OpenIO SDS : C SDK

Please refer to the dedicated Wiki page at https://github.com/open-io/oio-sds/wiki/C-SDK for more information.

