# OpenIO FS

## oiofs FUSE

oiofs FUSE is a FUSE adapter that allows you to mount OpenIO SDS containers as
filesystems on Linux systems.

oiofs FUSE provides another means to access OpenIO SDS Storage.
