/*
 *
 * Copyright 2015, OpenIO
 *
 */

#ifndef INCLUDE_OIOFS_H_
#define INCLUDE_OIOFS_H_


#define OIOFS_INO_ROOT    1

#define OIOFS_SETATTR_MODE   (1 << 0)
#define OIOFS_SETATTR_UID    (1 << 1)
#define OIOFS_SETATTR_GID    (1 << 2)
#define OIOFS_SETATTR_SIZE   (1 << 3)
#define OIOFS_SETATTR_ATIME  (1 << 4)
#define OIOFS_SETATTR_MTIME  (1 << 5)
// (1 << 6) is not defined in fuse_lowlevel.h
#define OIOFS_SETATTR_ATIME_NOW (1 << 7)
#define OIOFS_SETATTR_MTIME_NOW (1 << 8)

/* Maximum size for a file, arbitrarily set to 1TiB. */
#define OIOFS_MAX_FILE_SIZE ((size_t)1024*1024*1024*1024)

#endif  // INCLUDE_OIOFS_H_
